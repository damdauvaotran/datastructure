

public class Index {
    int index = 0 ;


    public Index() {
        this.index = 0;
    }

    public void plusPlus(){
        this.index++;
    }


}
